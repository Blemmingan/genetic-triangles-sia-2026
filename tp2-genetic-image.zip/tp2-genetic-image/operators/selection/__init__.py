from .elite import select as elite
from .roulette import select as roulette
from .tournament_deterministic import select as tournament_deterministic
from .tournament_probabilistic import select as tournament_probabilistic
from .ranking import select as ranking

__all__ = [
    "elite",
    "roulette",
    "tournament_deterministic",
    "tournament_probabilistic",
    "ranking",
]