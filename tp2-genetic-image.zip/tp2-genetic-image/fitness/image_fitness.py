import numpy as np
from PIL import Image
from typing import Any

from rendering.renderer import render


def image_to_array_rgb(image: Image.Image) -> np.ndarray:
    """
    Convierte una imagen Pillow a un array NumPy RGB normalizado en [0,1].

    Importante:
    en esta versión comparamos SOLO RGB, no alpha.

    ¿Por qué?
    Porque lo que nos interesa optimizar es la apariencia visual final
    de la imagen compuesta sobre fondo blanco.
    """
    image = image.convert("RGB")
    return np.asarray(image, dtype=np.float32) / 255.0


def compute_mse_rgb(target_image: Image.Image, rendered_image: Image.Image) -> float:
    """
    Calcula el error cuadrático medio (MSE) comparando solo RGB.
    """
    target_array = image_to_array_rgb(target_image)
    rendered_array = image_to_array_rgb(rendered_image)

    if target_array.shape != rendered_array.shape:
        raise ValueError(
            f"Las imágenes no tienen el mismo shape: "
            f"{target_array.shape} vs {rendered_array.shape}"
        )

    diff = target_array - rendered_array
    mse = np.mean(diff ** 2)

    return float(mse)


def compute_fitness(individual: Any, target_image: Image.Image) -> float:
    """
    Calcula la fitness de un individuo:

    1. renderiza el individuo
    2. compara la imagen renderizada con la imagen objetivo
       usando MSE sobre RGB
    3. transforma el error en fitness con:
           fitness = 1 - mse
    """
    image_size = target_image.size
    rendered_image = render(individual, image_size)

    mse = compute_mse_rgb(target_image, rendered_image)

    fitness = 1.0 - mse
    fitness = max(0.0, min(1.0, fitness))

    return fitness